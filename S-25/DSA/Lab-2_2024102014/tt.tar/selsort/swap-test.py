from swap import swap

assert(swap([2], 0, 0) == [2])
assert(swap([2, 3], 0, 1) == [3, 2])
