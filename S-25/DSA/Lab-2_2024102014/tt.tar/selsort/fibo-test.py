from fibo import fibo
assert(fibo(8)==13)