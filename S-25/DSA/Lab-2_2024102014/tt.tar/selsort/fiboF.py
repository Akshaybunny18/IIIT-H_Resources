from findmax import findmax
from swap import swap

# F:  X -> X
# X = Arr x Boundary
# x = (a, b)

# (ap, bp) = F(a, b)
def F(x):
    (a, b) = x  # pattern matching
    if b == len(a)-1:
        return x
    else:
        # temp=a
        # a=b
        # b=a+temp
        # return (a,b,c-1)
        for i in range(0,len(a)-b-1) :
            if (a[i]>a[j+1]) :
                swap(a[j],a[j+1])
        return (a,b+1)
