from findmax import findmax


assert(findmax([2], 1) == 0)
assert(findmax([2, 7], 2) == 1)
assert(findmax([2, 7], 1) == 0)
