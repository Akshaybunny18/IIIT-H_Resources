from bubsort import bubsort

assert(bubsort([]) == [])
assert(bubsort([9, 8, 12, 2]) == [2, 8, 9, 12])

