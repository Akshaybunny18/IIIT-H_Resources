/* 
 * Assignment 1 Problem 2
 */