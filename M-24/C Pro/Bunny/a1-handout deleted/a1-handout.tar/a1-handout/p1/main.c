/* 
 * Assignment 1 Problem 1
 */